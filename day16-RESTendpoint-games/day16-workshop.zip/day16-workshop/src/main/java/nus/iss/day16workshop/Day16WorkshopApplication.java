package nus.iss.day16workshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day16WorkshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day16WorkshopApplication.class, args);
	}

}
