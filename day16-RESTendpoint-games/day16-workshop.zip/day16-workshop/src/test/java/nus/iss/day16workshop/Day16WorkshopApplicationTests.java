package nus.iss.day16workshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day16WorkshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
