package sg.edu.nus.iss.d14lecture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D14LectureApplication {

	public static void main(String[] args) {
		SpringApplication.run(D14LectureApplication.class, args);
	}

}
