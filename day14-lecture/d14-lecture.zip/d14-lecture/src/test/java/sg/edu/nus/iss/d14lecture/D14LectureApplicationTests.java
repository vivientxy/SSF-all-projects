package sg.edu.nus.iss.d14lecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D14LectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
