package ibf2023.ssf.day12workshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day12workshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
