package ibf2023.ssf.day12workshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day12workshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day12workshopApplication.class, args);
	}

}
