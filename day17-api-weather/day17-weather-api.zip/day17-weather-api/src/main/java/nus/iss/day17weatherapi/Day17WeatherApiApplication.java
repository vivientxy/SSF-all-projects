package nus.iss.day17weatherapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day17WeatherApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day17WeatherApiApplication.class, args);
	}

}
