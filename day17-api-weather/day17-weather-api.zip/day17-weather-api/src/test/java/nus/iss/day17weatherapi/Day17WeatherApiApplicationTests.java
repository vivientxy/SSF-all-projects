package nus.iss.day17weatherapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day17WeatherApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
