package nus.iss.day17;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day17ApplicationTests {

	@Test
	void contextLoads() {
	}

}
