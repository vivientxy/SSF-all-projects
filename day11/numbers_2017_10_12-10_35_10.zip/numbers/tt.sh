for I in 20 21 22 23 24 25 26 27 28 29 30; do
	wget -A jpg "http://www.janbrett.com/images/number_${I}.jpg"
done
