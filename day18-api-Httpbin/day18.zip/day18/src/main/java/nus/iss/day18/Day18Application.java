package nus.iss.day18;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day18Application {

	public static void main(String[] args) {
		SpringApplication.run(Day18Application.class, args);
	}

}
