package ibf2023.ssf.day13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day13WorkshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day13WorkshopApplication.class, args);
	}

}
