package vttp2023.ssf.day19.day19;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day19ApplicationTests {

	@Test
	void contextLoads() {
	}

}
