package nus.iss.day16lecture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day16LectureApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day16LectureApplication.class, args);
	}

}
