package nus.iss.day16lecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day16LectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
