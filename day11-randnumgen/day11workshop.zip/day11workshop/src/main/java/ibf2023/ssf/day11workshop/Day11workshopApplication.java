package ibf2023.ssf.day11workshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day11workshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day11workshopApplication.class, args);
	}

}
