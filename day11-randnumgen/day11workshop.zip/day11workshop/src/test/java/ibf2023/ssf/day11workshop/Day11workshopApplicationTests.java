package ibf2023.ssf.day11workshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day11workshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
