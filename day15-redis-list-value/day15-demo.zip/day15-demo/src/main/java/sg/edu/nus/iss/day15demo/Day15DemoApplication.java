package sg.edu.nus.iss.day15demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day15DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day15DemoApplication.class, args);
	}

}
