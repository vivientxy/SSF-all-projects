package sg.edu.nus.iss.day15demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day15DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
