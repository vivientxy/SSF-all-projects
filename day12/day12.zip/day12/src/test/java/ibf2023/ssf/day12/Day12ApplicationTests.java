package ibf2023.ssf.day12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
